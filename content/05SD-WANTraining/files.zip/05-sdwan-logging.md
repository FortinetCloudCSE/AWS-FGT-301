# SD-WAN Logging in FMG with FAZ Log View

Since FAZ is joined as a Managed Device in FMG, the FAZ Views are now available in the FMG Console.

**Navigation:** FMG → Log View

For this demo, **9 Custom Log Views** have been created.

---

## SD-WAN Steering Traffic Logs

**Navigation:** FMG → Log View → Custom Views → SD-WAN Steering

With these logs you can show:

- DIA traffic getting steered out of **'port3'** via SD-WAN Rule #1 named **'DIA'**.
- In the next section (SD-WAN Link Impairment), you will come back to this view to show traffic has moved to **'port4'**.

> **Tip:** Highlight that you can create custom logging views and customise the column headers.
